export default [
  { id: "sysAdmin", name: "resources.roleSegments.data.sysAdmin" },
  { id: "apiAdmin", name: "resources.roleSegments.data.apiAdmin" },
  { id: "normal", name: "resources.roleSegments.data.normal" }
];
