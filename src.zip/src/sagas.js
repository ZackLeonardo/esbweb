import reviewSaga from './reviews/reviewSaga';

export default [reviewSaga];
